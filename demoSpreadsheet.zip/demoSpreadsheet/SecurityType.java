package com.example.drools.decision.demo.model;

public enum SecurityType {
    STOCK, BOND,ETF, MutualFund;
 
    public String getValue() {
        return this.toString();
    }
}
