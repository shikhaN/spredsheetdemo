package com.example.drools.decision.demo.model;

import lombok.Getter;
import lombok.Setter;
 
@Getter
@Setter
public class OrderDiscount {
 
    private Integer discount = 0;
}
